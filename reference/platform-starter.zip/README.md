# Sympl Pricing Analysis — Design System Starter

Everything a new AI coding session needs to build a Sympl-family platform that looks and behaves like **SymplPM**.

## What's included

### Instructions for the AI
- **`CLAUDE.md`**: project instructions Claude Code reads automatically. Covers architecture, conventions and design rules.
- **`AGENTS.md`**: Next.js 16 warning (its APIs differ from what models were trained on).
- **`docs/design-system.md`**: the full visual reference. Covers colours, typography, layout, component specs, page patterns and dependencies.

### Reference code (copied from SymplPM)
- **`src/components/ui/`**: the 8 shared primitives (Button, Input, Card, Dialog, Select, Badge, Tabs, Textarea).
- **`src/components/layout/`**: AppShell and Sidebar. These are cleaned up for a new app, with an example nav to replace.
- **`src/lib/utils.ts`**: `cn()` plus formatters.
- **`src/lib/prisma.ts`**: Prisma client singleton with the pg adapter.
- **`src/lib/category-paths.ts`**: tree helper for hierarchical pickers ("Parent > Child > Grandchild" labels, descendant lookup).
- **`src/types/next-auth.d.ts`**: adds `id` and `role` to the NextAuth session.
- **`src/app/globals.css`**, **`layout.tsx`**, **`providers.tsx`**: root setup (Tailwind v4, Geist font, SessionProvider).
- **`src/app/login-page-reference.tsx`**: the login page pattern. Move it to `src/app/login/page.tsx`.

## How to use
1. Create a new repo and add these files.
2. Start a Claude Code session on the repo.
3. Ask it to scaffold the Pricing Analysis platform. It will read `CLAUDE.md` and `docs/design-system.md` and match the SymplPM look and feel.

## Still to build in the new app
- `src/lib/auth.ts`: NextAuth v5 credentials provider (bcrypt and JWT) that exports `auth`, `signIn` and `signOut`. AppShell and the login page import it.
- `prisma/schema.prisma`: a `User` model with `role` (a `UserRole` enum), referenced by `next-auth.d.ts`.
- `src/app/(app)/layout.tsx`: wraps pages in `<AppShell>`.

## Branding
- Logo: "Sympl **PA**" (blue-400 on "PA"). This is already set in the sidebar and login reference.
- Page title: "Sympl PA". Already set in `layout.tsx`.
- Login subtitle: "Pricing Analysis Platform".
