import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { Sidebar } from "./sidebar";

// Wrap every authenticated page (src/app/(app)/layout.tsx) in this shell.
export async function AppShell({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <Sidebar user={{ name: session.user.name ?? session.user.email ?? "User", role: session.user.role ?? "" }} />
      <main className="flex-1 overflow-y-auto">{children}</main>
    </div>
  );
}
