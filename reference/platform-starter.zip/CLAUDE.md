# Sympl Pricing Analysis Platform

## Design System: "Sympl UI"

This platform MUST match the look, feel and UX patterns of the existing **SymplPM Product Development Platform**. The complete reference is `docs/design-system.md`. The components in `src/components/ui/` and `src/components/layout/` are the canonical implementations. Use them as they are, and extend rather than restyle them.

## Architecture

- **Framework:** Next.js 16 (App Router, Turbopack), React 19, TypeScript
- **Database:** PostgreSQL via Prisma 7 with `@prisma/adapter-pg` (see `src/lib/prisma.ts`)
- **Auth:** NextAuth v5 (credentials provider, bcrypt, JWT). The session carries `id` and `role` (`src/types/next-auth.d.ts`).
- **Styling:** Tailwind CSS v4. There is no tailwind.config; `globals.css` uses `@import "tailwindcss"`.
- **UI primitives:** Radix UI + class-variance-authority + tailwind-merge
- **Icons:** Lucide React (`h-5 w-5 shrink-0` in nav, `h-4 w-4` in buttons)
- **Fonts:** Geist (via `next/font/google`)
- **Excel:** ExcelJS. Use it to parse uploads (with size and column limits), and to write when styling or a template must be preserved.

## Key Conventions

- All pages under `src/app/(app)/` are authenticated and wrapped by AppShell.
- Login is at `src/app/login/page.tsx`: gray-900 background with a centred white card.
- Use `cn()` from `@/lib/utils` for all className merging.
- Primary colour is **blue-600** (buttons, active nav, focus rings).
- Sidebar: **gray-900** background, **blue-600** active item, **gray-300** inactive text. An item is active on an exact match or a child route (`/x` or `/x/…`), never a plain prefix.
- Content area: **gray-50** background; **white** cards with gray-200 borders.
- Text hierarchy: gray-900 headings, gray-700 body, gray-500 secondary, gray-400 placeholder.
- Forms use the Input, Select and Textarea components, not raw HTML elements.
- Dialogs use the provided `DialogContent`.
- Badges use the Badge component's semantic variants (default/secondary/success/warning/destructive/purple/outline).
- Tables: white background, gray-200 borders, gray-50 header row, text-sm, left-aligned.
- Hierarchical data (categories etc.) uses a `parentId` tree with no depth cap. Pickers show full paths via `categoryPaths()`, and moves are checked for cycles on the server.
- API routes check the session and then a permission. Validate and trim request bodies at the route boundary.
- React effects only set state inside async callbacks, never synchronously (the lint rule `react-hooks/set-state-in-effect` is on).

## Important: Next.js 16

@AGENTS.md

## File Structure

```
src/
  app/
    (app)/          # Authenticated routes (wrapped by AppShell)
      admin/        # Admin pages
      dashboard/    # Landing dashboard
    api/            # Route handlers (export only HTTP methods from route.ts)
    login/          # Public login page
    layout.tsx      # Root layout
    providers.tsx   # SessionProvider
    globals.css     # Tailwind + CSS variables
  components/
    layout/         # AppShell, Sidebar
    ui/             # Shared primitives
  lib/              # auth, prisma, utils, category-paths
  types/            # next-auth.d.ts
prisma/
  schema.prisma
```
